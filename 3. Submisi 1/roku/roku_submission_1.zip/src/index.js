import "./styles/main.scss";
import {main} from './app/main.js'
console.log("aditya negara");
const testingBabel = "Testing Babel";
console.log(testingBabel)
main();