const links = [
    {
        id : 1,
        href : "#hero-section",
        caption : "Home",
        tabindex : 4
    },
    {
        id: 2,
        href : "#",
        caption : "Favorites",
        tabindex : 5
    },
    {
        id: 3,
        href : "https://github.com/adityanegara",
        caption : "About",
        tabindex : 6
    }
]

export default links;