export const numberOne = document.getElementById('number-one');
export const numberTwo = document.getElementById('number-two'); 
export const plusButton = document.getElementById('plus-button');
export const result = document.getElementById('result');
export const alertMessage = document.getElementById('alert-message');
