const showElement = (element) =>{
    element.classList.remove("hidden");
    element.classList.add("block");
}

export default showElement;