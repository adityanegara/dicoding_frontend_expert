const hideElement = (element) =>{
    element.classList.remove("block");
    element.classList.add("hidden");
}

export default hideElement;