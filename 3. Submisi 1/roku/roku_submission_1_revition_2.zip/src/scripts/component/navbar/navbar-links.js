const links = [
    {
        id : 1,
        href : "/",
        caption : "Home",
        tabindex : 0
    },
    {
        id: 2,
        href : "#",
        caption : "Favorites",
        tabindex : 0
    },
    {
        id: 3,
        href : "https://github.com/adityanegara",
        caption : "About",
        tabindex : 0
    }
]

export default links;